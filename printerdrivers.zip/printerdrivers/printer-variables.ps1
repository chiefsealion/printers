﻿#Heirloom Roses Installation for Printers#

## File Directory Variables ##
if (-Not (Test-Path "C:\printers")) { New-Item "C:\Printers" -ItemType Directory }

$zipFilePath = "c:\printers"

$zipDestPath = "c:\printers"

## House / Office Printer Variables ##
$officePrinterINF = "KmInstall4.ini"

$officePrinterName = "StPaul - House Printer"

$officePrinterIP = "10.240.10.10"

$officePrinterDriver = "Kyocera TASKalfa 3554ci"

## Shipping Printer Variables ##
$shippingPrinterINF = "KmInstall4.ini"

$shippingPrinterName = "StPaul - Shipping Printer"

$shippingPrinterIP = "10.240.11.10"

$shippingPrinterDriver = "Kyocera TASKalfa 3552ci"

## Ops Trailer Printer Variables ##
$opsPrinterINF = "KmInstall4.ini"

$opsPrinterName = "StPaul - Ops Trailer"

$opsPrinterIP = "10.240.10.12"

$opsPrinterDriver = "Kyocera ECOSYS M6635cidn"


## Link to download the printer driver files ##
$downloadPrinterDriversURL = ""

Invoke-WebRequest -Uri $downloadPrinterDriversURL -OutFile $zipFilePath

##Unarchiving the printer driver files ##
Expand-Archive -LiteralPath $zipFilePath -DestinationPath $zipDestPath

##Actual Installation##

Install-Printer.ps1 -PortName "$officePrinterIP" -PrinterIP "$officePrinterIP" -PrinterName "$officePrinterName" -DriverName "$officePrinterDriver" -INFFile "$officePrinterINF"
Install-Printer.ps1 -PortName "$opsPrinterIP" -PrinterIP "$opsPrinterIP" -PrinterName "$opsPrinterName" -DriverName "$opsPrinterDriver" -INFFile "$opsPrinterINF"
Install-Printer.ps1 -PortName "$shippingPrinterIP" -PrinterIP "$shippingPrinterIP" -PrinterName "$shippingPrinterName" -DriverName "$shippingPrinterDriver" -INFFile "$shippingPrinterINF"

